package com.example.cadastropet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editTextNamePet, editTextCPF, editTextTelefone;
    private Button btnCadastrar, btnListarPets;
    private PetViewModel petViewModel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editTextNamePet = findViewById(R.id.editTextNomePet);
        editTextCPF = findViewById(R.id.editTextCPF);
        editTextTelefone = findViewById(R.id.editTextTelefone);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnListarPets = findViewById(R.id.btnListarPets);

        petViewModel = new PetViewModel(getApplication());

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarPet();
            }
        });

        btnListarPets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listarPets();
            }
        });
    }

    private void cadastrarPet() {
        String nome = editTextNamePet.getText().toString().trim();
        String cpf = editTextCPF.getText().toString().trim();
        String telefone = editTextTelefone.getText().toString().trim();

        if (nome.isEmpty() || cpf.isEmpty() || telefone.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }


        Pet pet = new Pet(cpf, nome, telefone, "", "", 0);

        petViewModel.insert(pet);
        Toast.makeText(this, "Pet cadastrado com sucesso", Toast.LENGTH_SHORT).show();


        editTextNamePet.setText("");
        editTextCPF.setText("");
        editTextTelefone.setText("");
    }

    private void listarPets() {
        startActivity(new Intent(MainActivity.this, ListarPetsActivity.class));
    }
}