package com.example.cadastropet;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "pets")
public class Pet {
    @PrimaryKey
    @NonNull
    public String cpf;
    public String nome;
    public String telefone;
    public String especie;
    public String raca;
    public int idade;

    public Pet(@NonNull String cpf, String nome, String telefone, String especie, String raca, int idade) {
        this.cpf = cpf;
        this.nome = nome;
        this.telefone = telefone;
        this.especie = especie;
        this.raca = raca;
        this.idade = idade;
    }
}