package com.example.cadastropet;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import java.util.ArrayList;
import java.util.List;

public class ListarPetsActivity extends AppCompatActivity {
    private ListView listViewPets;
    private PetViewModel petViewModel;
    private List<Pet> listaPets = new ArrayList<>();
    private ArrayAdapter<Pet> adapter;

   @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listar_activity);

        listViewPets = findViewById(R.id.listViewPets);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaPets);
        listViewPets.setAdapter(adapter);

        petViewModel = new ViewModelProvider(this).get(PetViewModel.class);
        petViewModel.getAllPets().observe(this, new Observer<List<Pet>>() {
            @Override
            public void onChanged(List<Pet> pets) {
                listaPets.clear();
                listaPets.addAll(pets);
                adapter.notifyDataSetChanged();
            }
        });

        listViewPets.setOnItemClickListener((parent, view, position, id) -> {
            Pet pet = listaPets.get(position);
            petViewModel.deleteByCpf(pet.cpf);
        });
    }
}