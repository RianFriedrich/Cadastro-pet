package com.example.cadastropet;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class PetViewModel extends AndroidViewModel {
    private PetRepository repository;
    private LiveData<List<Pet>> allPets;

    public PetViewModel(Application application) {
        super(application);
        repository = new PetRepository(application);
        allPets = repository.getAllPets();
    }

    public LiveData<List<Pet>> getAllPets() {
        return allPets;
    }

    public void insert(Pet pet) {
        repository.insert(pet);
    }

    public void deleteByCpf(String cpf) {
        repository.deleteByCpf(cpf);
    }
}