package com.example.cadastropet;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PetDao {
    @Insert
    void insert(Pet pet);

    @Query("SELECT * FROM pets")
    List<Pet> getAllPets();

    @Query("DELETE FROM pets WHERE cpf = :cpf")
    void deleteByCpf(String cpf);
}