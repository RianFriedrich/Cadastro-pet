package com.example.cadastropet;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;
import androidx.annotation.NonNull;

@Database(entities = {Pet.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract PetDao petDao();

    private static volatile AppDatabase INSTANCE;

    // Método para pegar a instância do banco de dados
    public static AppDatabase getInstance(@NonNull Context context) {
        if (INSTANCE == null) { // Se o banco de dados ainda não foi criado, cria uma nova instância
            synchronized (AppDatabase.class) {  // Bloqueia o código para garantir thread-safety
                if (INSTANCE == null) { // Dupla verificação para garantir a criação de uma única instância
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(), // Usa o contexto da aplicação para evitar vazamento de memória
                                    AppDatabase.class, // Define esta classe como o banco de dados Room
                                    "banco-de-dados" // Nome do arquivo do banco de dados armazenado no dispositivo
                            )
                            .build(); // Cria e retorna a instância do banco de dados
                }
            }
        }
        return INSTANCE; // Retorna a instância única do banco de dados
    }
}
