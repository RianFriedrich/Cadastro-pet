package com.example.cadastropet;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class PetRepository {
    private PetDao petDao;
    private LiveData<List<Pet>> allPets;

    public PetRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        petDao = db.petDao();
        allPets = (LiveData<List<Pet>>) petDao.getAllPets();
    }

    public LiveData<List<Pet>> getAllPets() {
        return allPets;
    }

    public void insert(Pet pet) {
        new InsertPetAsyncTask(petDao).execute(pet);
    }

    public void deleteByCpf(String cpf) {
        new DeletePetAsyncTask(petDao).execute(cpf);
    }

    private static class InsertPetAsyncTask extends AsyncTask<Pet, Void, Void> {
        private PetDao asyncTaskDao;

        InsertPetAsyncTask(PetDao dao) {
            asyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Pet... params) {
            asyncTaskDao.insert(params[0]);
            return null;
        }
    }

    private static class DeletePetAsyncTask extends AsyncTask<String, Void, Void> {
        private PetDao asyncTaskDao;

        DeletePetAsyncTask(PetDao dao) {
            asyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final String... params) {
            asyncTaskDao.deleteByCpf(params[0]);
            return null;
        }
    }
}